<div class="wrap">
    <h1><?php _e('Rooms', 'skyroom') ?></h1>
    <form id="rooms-form" method="get">
        <?php $table->display() ?>
    </form>
</div>