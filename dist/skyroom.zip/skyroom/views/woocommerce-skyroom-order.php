<section class="wocommerce-order-skyroom">
    <h2 class="woocommerce-order-downloads__title"><?php esc_html_e('Courses', 'skyroom'); ?></h2>
    <p><?php esc_html_e("You successfully enrolled in purchased courses. To attend classes, on announced schedules navigate to course page and click on 'Enter room' button. (Remember you should be logged in to site)", 'skyroom') ?></p>
</section>