<div class="wrap">
    <h1><?php _e('Events', 'skyroom') ?></h1>
    <form id="events-form" method="get">
        <?php $table->display() ?>
    </form>
</div>