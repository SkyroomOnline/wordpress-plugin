<div class="skyroom-error-wrapper">
    <div class="skyroom-error-img">
        <img src="<?php echo $this->pluginUrl ?>admin/images/error.png">
    </div>
    <div class="skyroom-error-message">
        <?php echo $error ?>
    </div>
</div>